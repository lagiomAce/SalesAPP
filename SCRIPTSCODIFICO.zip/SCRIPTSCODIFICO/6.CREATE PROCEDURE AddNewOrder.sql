CREATE PROCEDURE AddNewOrder
    @EmpID INT,
    @ShipperID INT,
    @ShipName NVARCHAR(100),
    @ShipAddress NVARCHAR(255),
    @ShipCity NVARCHAR(100),
    @OrderDate DATE,
    @RequiredDate DATE,
    @ShippedDate DATE NULL,
    @Freight DECIMAL(10,2),
    @ShipCountry NVARCHAR(100),
    @CustomerID INT,
    @ProductID INT,
    @UnitPrice DECIMAL(10,2),
    @Qty INT,
    @Discount DECIMAL(5,2),
    @OrderID INT OUTPUT,  
    @CustID INT OUTPUT   
AS
BEGIN
    SET NOCOUNT ON;

    -- Insertar la nueva orden
    INSERT INTO Sales.Orders (EmpID, ShipperID, ShipName, ShipAddress, ShipCity, OrderDate, RequiredDate, ShippedDate, Freight, ShipCountry, CustID)
    VALUES (@EmpID, @ShipperID, @ShipName, @ShipAddress, @ShipCity, @OrderDate, @RequiredDate, @ShippedDate, @Freight, @ShipCountry, @CustomerID);


    SET @OrderID = SCOPE_IDENTITY();

    -- Insertar en OrderDetails
    INSERT INTO Sales.OrderDetails (OrderID, ProductID, UnitPrice, Qty, Discount)
    VALUES (@OrderID, @ProductID, @UnitPrice, @Qty, @Discount);

    
    SET @CustID = @CustomerID;
END;

