CREATE PROCEDURE GetProducts
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        productid,
        productname
    FROM Production.Products
    ORDER BY productname;  
END;


