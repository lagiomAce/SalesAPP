EXEC AddNewOrder 
    @EmpID = 3, 
    @ShipperID = 2, 
    @ShipName = 'Mi Empresa', 
    @ShipAddress = 'Calle Principal 123', 
    @ShipCity = 'CiudadX', 
    @OrderDate = '2025-02-06', 
    @RequiredDate = '2025-02-10', 
    @ShippedDate = NULL, 
    @Freight = 50.00, 
    @ShipCountry = 'PasX',
    @customerID = 2
    @ProductID = 50, 
    @UnitPrice = 20.50, 
    @Qty = 5, 
    @Discount = 0.00;