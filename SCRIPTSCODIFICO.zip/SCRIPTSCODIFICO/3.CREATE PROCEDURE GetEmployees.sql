CREATE PROCEDURE GetEmployees
AS
BEGIN
    SET NOCOUNT ON;

   
    SELECT 
        empid,
        CONCAT(FirstName, ' ', LastName) AS FullName  
    FROM HR.Employees
    ORDER BY FullName; 
END;

