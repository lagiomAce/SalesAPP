CREATE PROCEDURE GetClientOrders
    @CustID INT 
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        orderid,
        requireddate,
        shippeddate,
        shipname,
        shipaddress,
        shipcity
    FROM Sales.Orders
    WHERE custid = @CustID
    ORDER BY RequiredDate DESC; 
END;

