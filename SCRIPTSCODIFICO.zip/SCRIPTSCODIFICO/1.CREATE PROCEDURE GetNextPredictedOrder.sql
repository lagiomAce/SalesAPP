CREATE PROCEDURE GetNextPredictedOrder
    @CustID INT = NULL  
AS
BEGIN
    SET NOCOUNT ON;

    WITH OrderIntervals AS (
     
        SELECT 
            o.custid,
            DATEDIFF(DAY, LAG(o.orderDate) OVER (PARTITION BY o.custid ORDER BY o.OrderDate), o.OrderDate) AS DaysBetweenOrders
        FROM Sales.Orders o
    ),
    AvgOrderIntervals AS (
    
        SELECT 
            custid,
            AVG(CAST(DaysBetweenOrders AS FLOAT)) AS AvgDaysBetweenOrders
        FROM OrderIntervals
        WHERE DaysBetweenOrders IS NOT NULL 
        GROUP BY custid
    ),
    LastOrder AS (
       
        SELECT 
            o.custid,
            MAX(o.OrderDate) AS LastOrderDate
        FROM Sales.Orders o
        GROUP BY o.custid
    )

   
    SELECT 
        c.custid, 
        c.companyname AS CustomerName,
        lo.LastOrderDate,
        DATEADD(DAY, COALESCE(aoi.AvgDaysBetweenOrders, 0), lo.LastOrderDate) AS NextPredictedOrder
    FROM Sales.Customers c
    JOIN LastOrder lo ON c.custid = lo.custid
    LEFT JOIN AvgOrderIntervals aoi ON c.custid = aoi.custid
    WHERE (@CustID IS NULL OR c.custid = @CustID)  
    ORDER BY NextPredictedOrder;
END;
