CREATE PROCEDURE GetShippers
AS
BEGIN
    SET NOCOUNT ON;

    
    SELECT 
        shipperid,
        companyname
    FROM Sales.Shippers
    ORDER BY CompanyName; 
END;


